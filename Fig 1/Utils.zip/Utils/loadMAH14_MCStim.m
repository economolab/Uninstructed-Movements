function meta = loadMAH14_MCStim(meta,datapth)

meta(end+1).datapth = datapth;
meta(end).anm = 'MAH14';
meta(end).date = '2022-12-08';
meta(end).datafn = findDataFn(meta(end));
meta(end).datapth = fullfile(meta(end).datapth,'DataObjects',meta(end).anm,meta(end).datafn);

meta(end+1).datapth = datapth;
meta(end).anm = 'MAH14';
meta(end).date = '2022-12-09';
meta(end).datafn = findDataFn(meta(end));
meta(end).datapth = fullfile(meta(end).datapth,'DataObjects',meta(end).anm,meta(end).datafn);

meta(end+1).datapth = datapth;
meta(end).anm = 'MAH14';
meta(end).date = '2022-12-12';
meta(end).datafn = findDataFn(meta(end));
meta(end).datapth = fullfile(meta(end).datapth,'DataObjects',meta(end).anm,meta(end).datafn);

meta(end+1).datapth = datapth;
meta(end).anm = 'MAH14';
meta(end).date = '2022-12-07';
meta(end).datafn = findDataFn(meta(end));
meta(end).datapth = fullfile(meta(end).datapth,'DataObjects',meta(end).anm,meta(end).datafn);

meta(end+1).datapth = datapth;
meta(end).anm = 'MAH14';
meta(end).date = '2022-12-14';
meta(end).datafn = findDataFn(meta(end));
meta(end).datapth = fullfile(meta(end).datapth,'DataObjects',meta(end).anm,meta(end).datafn);

meta(end+1).datapth = datapth;
meta(end).anm = 'MAH14';
meta(end).date = '2022-12-15';
meta(end).datafn = findDataFn(meta(end));
meta(end).datapth = fullfile(meta(end).datapth,'DataObjects',meta(end).anm,meta(end).datafn);

meta(end+1).datapth = datapth;
meta(end).anm = 'MAH14';
meta(end).date = '2022-12-16';
meta(end).datafn = findDataFn(meta(end));
meta(end).datapth = fullfile(meta(end).datapth,'DataObjects',meta(end).anm,meta(end).datafn);

meta(end+1).datapth = datapth;
meta(end).anm = 'MAH14';
meta(end).date = '2022-12-19';
meta(end).datafn = findDataFn(meta(end));
meta(end).datapth = fullfile(meta(end).datapth,'DataObjects',meta(end).anm,meta(end).datafn);

meta(end+1).datapth = datapth;
meta(end).anm = 'MAH14';
meta(end).date = '2022-12-20';
meta(end).datafn = findDataFn(meta(end));
meta(end).datapth = fullfile(meta(end).datapth,'DataObjects',meta(end).anm,meta(end).datafn);

end