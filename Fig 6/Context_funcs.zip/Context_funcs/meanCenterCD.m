function curr = meanCenterCD(sessix, curr) 
bothprojs = curr(sessix).cd_proj;
        avg = mean(bothprojs,2,'omitnan');
        avg = mean(avg);
        curr(sessix).cd_proj = curr(sessix).cd_proj-avg;
end