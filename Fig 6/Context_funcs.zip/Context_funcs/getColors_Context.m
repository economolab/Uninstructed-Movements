function clrs = getColors_Context()

clrs.AFChit = [0 0 0];
clrs.AWhit = [1 0 1];
clrs.rmiss = [0 154 255]./255;
clrs.lmiss = [255 77 0]./255;



end